<?php
    define('BASE_PATH', __DIR__);
    define('APP_PATH', BASE_PATH . '/app');
    define('PUBLIC_PATH', BASE_PATH . '/public');

    // Tự động nhận base URL theo thư mục
    define('BASE_URL', 'http://freshfruitjuice.lovestoblog.com');

    require_once APP_PATH . '/init.php';
?>