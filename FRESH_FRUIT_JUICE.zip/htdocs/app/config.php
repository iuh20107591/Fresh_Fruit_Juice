<?php
    return [
        'db' => [
            'host' => 'sql313.infinityfree.com',
            'user' => 'if0_39414268',
            'pass' => 'khanh01112002',
            'name' => 'if0_39414268_ffj'
        ]
    ];
?>