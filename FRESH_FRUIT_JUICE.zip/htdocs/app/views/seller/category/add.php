<h3>➕ Thêm loại sản phẩm</h3>
<form method="post">
    <div class="mb-3">
        <label>Tên loại</label>
        <input type="text" name="cat_name" class="form-control" required>
    </div>
    <button class="btn btn-success">Thêm</button>
</form>
