<?php
if (!defined('APP_PATH')) {
    define('APP_PATH', dirname(__DIR__) . '/app');
}
require_once APP_PATH . '/core/app.php';
require_once APP_PATH . '/core/controller.php';
